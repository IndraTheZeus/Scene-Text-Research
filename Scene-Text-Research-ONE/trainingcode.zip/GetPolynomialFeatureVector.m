function PolyVector = GetPolynomialFeatureVector(X,power)

  %Input Needs to have data as row wise form
     %Features: 
    % 1. Del(No. of Pixels Bin i - Bin i + SubBin(i-1,i+1))/Total No. of Pixels
    % 2. Del(No. of Pixels Bin i - Bin(i,i+1,i-1))/Total No. of Pixels
    % 3. No. of Holes
    % 4. Del(No. of Holes Bin i - Bin i + SubBin(i-1,i+1))
    % 5. Del(No. of Holes Bin i - Bin i + Bin(i-1,i+1))
    % 6. Density 
    % 7. Del(Change of Density of Bin i - Bin i + SubBin(i-1,i+1))/Density
    % 8. Del(Change of Density of Bin i - Bin i + Bin(i,i-1,i+1))/Density
    % 9. Number of Pixels
    % 10. BinSize
    % 11.Lower Range Increment Check
    % 12. Higher Range Increment Check
    
    
    %%Normalized Feature Vectors with Polynomial and multiplied features
    
    
    PolyVector = X;
    
    for i = 2:power
        
       PolyVector = [PolyVector X.^i]; 
    end
    
    PolyVector = [ones(size(PolyVector,1),1) PolyVector];
    

end